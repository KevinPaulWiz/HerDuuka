<?php 
// session_start();
include 'assets/header.php';
include 'config/controller.php';
 ?>    	

		<!-- MAIN -->
		<main class="site-main">

            
            <div class="columns container">
                <!-- Block  Breadcrumb-->

                <!-- manufacturers -->

        <!-- //manufacturers -->
                <div class="page-content pb-3">
                    <div class="row ">
                        <?php echo $Error; ?>
                        <form method="post" action="<?php echo htmlspecialchars($_SERVER[""]);?>">
                    <div class=" col-sm-3 ">
                        <div class="bg-light " id="sidebar-wrapper">
      <div class="list-group list-group-flush">
        <a href="#" class="list-group-item list-group-item-action bg-light border-color"><i class="fa fa-bars"></i> My Alipata Account</a>
        <a href="#" class="list-group-item list-group-item-action bg-light"><i class="fa fa-history"></i> Order History</a>
        <a href="#" class="list-group-item list-group-item-action bg-light"><i class="fa fa-home"></i> Addresses</a>
        <a href="#" class="list-group-item list-group-item-action bg-light"><i class="fa fa-heart"></i> Wishlist</a>
        <a href="#" class="list-group-item list-group-item-action bg-light"><i class="fa fa-commenting"></i> Pending Reviews</a>
        <a href="#" class="list-group-item list-group-item-action bg-light"><i class="fa fa-key"></i> Password</a>
        <a href="#" class="list-group-item list-group-item-action bg-light"><i class="fa fa-envelope"></i> Newsletter Preferences</a>
        <a href="#" class="list-group-item list-group-item-action bg-light"><i class="fa fa-sign-out"></i> Logout</a>
      </div>
    </div>
                    </div>
                </form>
                        <div class="col-sm-9">
                            <div class="box-border pt-0 mt-0">
                                <h3 class="pt-0 mt-3">Addresses</h3>
                                <br>
                            <div class="mt-4 mt-lg-0">
                                <div class="addresses-list">
                                    <a href="#" class="addresses-list__item addresses-list__item--new"><div class="addresses-list__plus">
                                        
                                    </div>
                                    <div class="btn btn-secondary btn-sm">Add New</div>
                                </a><div class="addresses-list__divider">
                                    
                                </div>
                                <div class="addresses-list__item card address-card shadow-sm box-border">
                                    <div class="bg-primary pl-3 pr-3 address-card__badge tag-badge tag-badge--theme">Default</div>
                                    <div class="address-card__body"><div class="address-card__name">Helena Garcia</div>
                                    <div class="address-card__row">Random Federation<br>115302, Moscow<br>ul. Varshavskaya, 15-2-178</div>
                                    <div class="address-card__row"><div class="address-card__row-title">Phone Number</div>
                                    <div class="address-card__row-content">38 972 588-42-36</div>
                                </div>
                                    <div class="address-card__row"><div class="address-card__row-title">Email Address</div>
                                    <div class="address-card__row-content">helena@example.com</div>
                                </div>
                                    <div class="address-card__footer"><a class="text-primary" href="#">Edit</a>&nbsp;&nbsp; <a href="#" class="text-primary">Remove</a></div>
                                </div>
                                </div>
                                    <div class="addresses-list__divider"></div>
                                    <div class="addresses-list__item card address-card"><div class="address-card__body"><div class="address-card__name">Jupiter Saturnov</div>
                                    <div class="address-card__row">RandomLand<br>4b4f53, MarsGrad<br>Sun Orbit, 43.3241-85.239</div>
                                    <div class="address-card__row"><div class="address-card__row-title">Phone Number</div>
                                    <div class="address-card__row-content">ZX 971 972-57-26</div>
                                </div>
                                    <div class="address-card__row"><div class="address-card__row-title">Email Address</div>
                                    <div class="address-card__row-content">jupiter@example.com</div>
                                </div>
                                    <div class="address-card__footer"><a class="text-primary" href="#">Edit</a>&nbsp;&nbsp; <a class="text-primary" href="#">Remove</a></div>
                                </div>
                                </div>
                                    <div class="addresses-list__divider"></div>
                                </div>
                                </div>

</div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>


		</main><!-- end MAIN -->

		<?php include 'assets/footer.php'; ?>