
<?php 
include 'assets/header.php';
include("inc/config.inc.php");
?>           	

<!-- MAIN -->
<main class="site-main">

<div class="columns container">
<!-- Block  Breadcrumb-->
        
<ol class="breadcrumb no-hide">
    <li><a href="#">Home    </a></li>
    <li class="active"> <?php echo $title; ?></li>
</ol><!-- Block  Breadcrumb-->

<!-- <h2 class="page-heading">
    <span class="page-heading-title2"> Cart (<?PHP if(isset($_SESSION["products"])){echo count($_SESSION["products"]); } ?> item<?php if (count($_SESSION["products"])>1) {echo "s";}else{} ?>)</span>
</h2> -->

<div class=" ">
    <!-- <h3 class="checkout-sep">6. Order Review</h3> -->
    <div class="box-border shadow rounded p-0">
        <div class="  p-0">
          <!-- Header for Shopping -->
  <div class="col-sm-12 p-0 box-border">
    <div class="border-bottom p-0 m-0">
    <div class="col-sm-4 p-0 bg-dark text-white ">
      <div class="pl-4 pr-1  pb-0 p-4 pt-4">
         <h4 class="text-uppercase">Need Help?</h4>
      <p>If you need help, contact us and let us help you. 
        Support is availabe 24hours. </p>
        <p class="p-0 ">
          <b>+256 702 978 248,    support@alipata.com</b>
        </p>
      </div>
    </div>
  

                        <div class="container">
                            <div class="row text-center col-sm-8 mt-5">
                                <div class="col-xs-3">
                                    <div class="icon-stack icon-stack-xl  bg-gradient-primary-to-secondary text-white mb-4 mt-4" >
                                      <a href="">
                                      <!-- <div class="col-xs-3"> -->
                                      <span style="border-radius: 100%;"  class="p-4 bg-dark text-white ">
                                      <b class="h3 mb-2 ">1</b>
                                      </span>
                                      <!-- </div> -->
                                      </a>
                                    </div>
                                    <h4 class="text-uppercase pt-2">cart</h4>
                                </div>
                            <div class="col-xs-3">
                                    <div class="icon-stack icon-stack-xl  bg-gradient-primary-to-secondary text-white mb-4 mt-4" >
                                      <a href="">
                                      <!-- <div class="col-xs-3"> -->
                                      <span style="border-radius: 100%;"  class="p-4  bg-dark text-white  active border  ">
                                      <b class="h3 mb-2 ">2</b>
                                      </span>
                                      <!-- </div> -->
                                      </a>
                                    </div>
                                    <h4 class="text-uppercase pt-2">information</h4>
                                </div>
                            <div class="col-xs-3">
                                    <div class="icon-stack icon-stack-xl  bg-gradient-primary-to-secondary text-white mb-4 mt-4" >
                                      <a href="">
                                      <!-- <div class="col-xs-3"> -->
                                      <span style="border-radius: 100%;"  class="p-4  bg-dark text-white  active border  ">
                                      <b class="h3 mb-2 ">3</b>
                                      </span>
                                      <!-- </div> -->
                                      </a>
                                    </div>
                                    <h4 class="text-uppercase pt-2">Shipping</h4>
                                </div>
                            <div class="col-xs-3">
                                    <div class="icon-stack icon-stack-xl  bg-gradient-primary-to-secondary text-white mb-4 mt-4" >
                                      <a href="">
                                      <!-- <div class="col-sm-3"> -->
                                      <span style="border-radius: 100%;"  class="p-4  bg-dark text-white  active border ">
                                      <b class="h3 mb-2 ">4</b>
                                      </span>
                                      <!-- </div> -->
                                      </a>
                                    </div>
                                    <h4 class="text-uppercase pt-2">Payment</h4>
                                </div>


                            </div>
                            </div>
                        </div>
<div class="col-sm-12 pt-5 pb-2">
  <h3 class="pb-5">
    <span class="text-uppercase"> Payment method <br><b class="p-0 ml-0 m-0  font-weight-bold h4"><img class="p-0 mb-5" src="images/media/index1/sectionheader.png" alt="logo"></b></span>
</h3>
<h4 class="">
  <div class=" mb-5  font-weight-bold h4 float-left">
    <div style="border-top: 3px solid #ff3300; max-width: 47px;" >&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</div>
  </div>
    <span class="text-uppercase"> Estimation <br></span>
</h4>
<p>You can remove and add quantity to each in the cart.</p>
<!-- products -->
<?php 
if(isset($_SESSION["products"]) && count($_SESSION["products"])>0){
    $total = 0;
    $list_tax = '';           
    $cart_box = '';
    foreach($_SESSION["products"] as $product){
        $product_name = $product["product_name"];
        $product_quantity = $product["product_quantity"];
        $product_price = $product["Price"];
        $product_id = $product["product_id"];
        $product_color = $product["product_color"];         
        $item_price = sprintf("%01.2f",($product_price * $product_quantity));  

        $subtotal = ($product_price * $product_quantity);
        $total = ($total + $subtotal);
    }   
    include("inc/config.inc.php");
     $shipping_cost=count($_SESSION["products"])*$shipping_cost;
    $grand_total = $total + $shipping_cost;
    foreach($taxes as $key => $value){
            $tax_amount = round($total * ($value / 100));
            $tax_item[$key] = $tax_amount;
            $grand_total = $grand_total + $tax_amount; 
    }   
    foreach($tax_item as $key => $value){
        $list_tax .= $key. ' : '. $currency. sprintf("%01.2f", $value).'<br />';
    }   
    // $shipping_cost = ($shipping_cost)?'Shipping Cost : '.$currency. sprintf("%01.2f", $shipping_cost).'<br />':'';  
    $cart_box .= "<span>$shipping_cost  $list_tax <hr>Payable Amount : $currency ".sprintf("%01.2f", $grand_total)."</span>";  
 } ?>
<div class="col-sm-12 p-0 m-0 " id="shopping-cart-results"> 
              <div class="card-body"  id="view_cart" >               
                <div class="alert alert-deflaut box-border rounded shadow-sm p-0 " role="alert">
                  <div class="col-xs-8 p-0 m-0 pt-3 pl-3">
                    <a href="product-item-detail?ALeKk00B5oNZEMbYSCnkFSzNInJ_GNCfY=uHSZXuqHIYmAhbIP06KXuAE&id=<?php echo $prod['product_id']; ?>">
                        <?php
                        $sql = "SELECT image_path, product_id FROM product_images WHERE product_id='$product_id'";
                        $result = $conn->query($sql);
                        $row = $result->fetch_assoc();
                        ?>
                  <div class="float-left p-0 pr-5">
                  <img style="max-width: 30px;" class="img-fluid img-responsive  pt-0 mt-0" src="images/icon/index1/nav-cat5-hover.png" alt="Product">
                  </div>
                </a>
                  <div class="p-0 pb-3">
                    <h4 class="alert-heading font-weight-bold p-0 m-0 ">Grand Total <span class="text-light "> <?PHP if(isset($_SESSION["products"])){echo count($_SESSION["products"]); } ?> item<?php if (count($_SESSION["products"])>1) {echo "s";}else{} ?></span></h4>
                         
                  </div>
                  </div>
                  <div class="col-xs-4 p-0 m-0 pr-3  float-right">
                   <div class="float-right ">
                    <h4 class="text-primary mt-3">
                      
                    <?php echo $currency; echo number_format(($grand_total), 0, '.', ','); ?>
                  </h4>
                   </div>     
                  </div>
                </div>
                
              </div> 

  </div>
  <h4 class="">
  <div class=" mb-5  font-weight-bold h4 float-left">
    <div style="border-top: 3px solid #ff3300; max-width: 47px;" >&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</div>
  </div>
    <span class="text-uppercase"> Estimation <br></span>
</h4>
<?php 
 if ($_SERVER["REQUEST_METHOD"] == "POST") {      
  if (isset($_POST['placeorder'])) {
    // Order No
$orderNo=$_SESSION['order_No'];
$customers_email=$_SESSION['customer_email'];

include("config/connection.php");
try {
$conn = new PDO("mysql:host=$servername;dbname=$dbname", $username, $password);
// set the PDO error mode to exception
$conn->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);

$sql = "UPDATE `orders` SET `payment_id`='1'  AND ordernumber='".$_SESSION["order_No"]."'";

// Prepare statement
$stmt = $conn->prepare($sql);

// execute the query
$stmt->execute();
$orderNo=$_SESSION['order_No'];
// echo a message to say the UPDATE succeeded
// echo $stmt->rowCount() . " records UPDATED successfully";

 /**************************products******************************/






$to = "$customers_email";
$subject = "Your Alipata Order 307329792 has been confirmed.";
$htmlContent = "
<!DOCTYPE html>
<html>
<head>
  <title></title>
</head>
<body>
<div class=''><div class='aHl'></div>
<div id=':1qb' tabindex='-1'></div>
<div id=':1r4' class='ii gt'>
    <div id=':1r3' class='a3s aXjCH msg-4380193512371063790'>
        <u></u>

    <div style='width:100%;margin:10px 0 0 0'>
        <div style=' background-color:#e2e8e9 !important;'>
        <table width='100%' cellpadding='0' cellspacing='0' border='0' bgcolor='#e2e8e9' style='font-family:Helvetica Neue,Helvetica,Arial,sans-serif;font-size:13px;'>
            <tbody><tr>
                <td bgcolor='#e2e8e9' width='100%'>

                    <table width='600' cellpadding='0' cellspacing='0' border='0' align='center' class='m_-4380193512371063790tablewrapper' style='padding: 20px;'>
                        <tbody><tr>
                            <td width='600' style=' background-color:#f1f6fa !important; -webkit-box-shadow: inset 0 1px 1px rgba(0,0,0,.075), 0 0 8px rgba(102, 175, 233, .6); border-radius: 10px;'>

                                
                                <table class='m_-4380193512371063790tableheader' width='100%' cellspacing='0' cellpadding='0' style='vertical-align:middle; border-top: 2px solid #ff4d01;  border-radius: 10px;'>
                                    <tbody>
                                        <tr  style='border-radius: 10px;'>
                                        <td class='m_-4380193512371063790header' align='center' style='max-width:100%;text-align:center;vertical-align:middle'>
                                            <div style='height:100%;width:100%;vertical-align:middle;display:table;text-align:center' valign='center'>
                                                <span style='display:table-cell;vertical-align:middle;text-align:center'> <a href='http://email.mg.alipata.com/c/eJwtj0FrwzAMhX-NcykJslKnzSGHdFm7S9lg62WXotle6jWOQ2ovsF8_uxSEEE-feHqqkQKglplpEBBAACKIimPBC8GrLQrcrsuy6rpux9Zg--InWEOFdDa7NERfAr4FKKXkpq7XxEsl4kmNxGtOmA3NxfuJlS3DfaxlWR73oU9KuR_d5OK-83PQDKvg7dlqZYKNmrZkhod4c2GW-g7SeCPpjRtpOCfiFpEHJclOZPoxcilNDiIH_ECID4gqNs4_H6TXc7I4HXImdkx0-ctzG9tbNjdX_WvGicKwmL8YuU8e97y-eXLWhtFISvaro1Nh0FF-Pb5nijw1bLNj0K5WDHHUfnHzNU7RNwmnQ5qhZZvuH1crb_Y' target='_blank' data-saferedirecturl='https://www.google.com/url?q=http://email.mg.alipata.com/c/eJwtj0FrwzAMhX-NcykJslKnzSGHdFm7S9lg62WXotle6jWOQ2ovsF8_uxSEEE-feHqqkQKglplpEBBAACKIimPBC8GrLQrcrsuy6rpux9Zg--InWEOFdDa7NERfAr4FKKXkpq7XxEsl4kmNxGtOmA3NxfuJlS3DfaxlWR73oU9KuR_d5OK-83PQDKvg7dlqZYKNmrZkhod4c2GW-g7SeCPpjRtpOCfiFpEHJclOZPoxcilNDiIH_ECID4gqNs4_H6TXc7I4HXImdkx0-ctzG9tbNjdX_WvGicKwmL8YuU8e97y-eXLWhtFISvaro1Nh0FF-Pb5nijw1bLNj0K5WDHHUfnHzNU7RNwmnQ5qhZZvuH1crb_Y&amp;source=gmail&amp;ust=1590576057621000&amp;usg=AFQjCNEnPw2ImCjWkTn7WgOxKouSk6elRg'>                                         
                                                <img width='450' style='padding:20px;' class='m_-4380193512371063790imageheader CToWUd' valign='center' src='http://alipata.com/images/icon/logo.png'>
                                                </a>
                                                </span>
                                            </div>
                                        </td>
                                    </tr>
                                </tbody></table>
                                <table class='m_-4380193512371063790promocat' width='100%' cellspacing='0' cellpadding='0' style='background:#fff;padding-left:5px;font-size:11px; '>
                                    <tbody>
                                        <tr border='0'>
                                        <td class='m_-4380193512371063790promocat' style='text-align:center;width:15%; background: #ff4d01;border-radius: 50px; color: white;'>
                                            <a href='http://email.mg.alipata.com/c/eJwtkMFugzAMhp8mXCqQCQ2FAwfatN2hVQ9dL7ugEALNSgiCZGh7-iUVkmXZvz47f9wUnADkPJAFBgxAAGMgaYyjOCJxmmGCs22SpJTSPdqC6qJvqySLuFbBs-AiaUWbpywhdZ2nCWkhg6wVGdlts7whQV88jRlRUiJ8crEsyzpvO9e2bH5KPYT1b_hWPZScBj1qN0LNZAXCqTWqUqKRVjlNKCb7VZy1nbh4g2yYGTduFesrT8wrwpkamewGB_nfhUBCwJ8YnCGSuhTHXytpxOT3P84hIvtjdThV9HivPo4ldf3hcqvKy-WOCA2m4iV-5DAy2y_yz52k8w--72GKg1bKDpIz72Vz1Y3thZNv13vQMMMKtNsjKDcbhPEgzKKnl6ucDy88zr6GEu3oP1owe0Q' style='text-decoration:none;color:inherit;' target='_blank' data-saferedirecturl='https://www.google.com/url?q=http://email.mg.alipata.com/c/eJwtkMFugzAMhp8mXCqQCQ2FAwfatN2hVQ9dL7ugEALNSgiCZGh7-iUVkmXZvz47f9wUnADkPJAFBgxAAGMgaYyjOCJxmmGCs22SpJTSPdqC6qJvqySLuFbBs-AiaUWbpywhdZ2nCWkhg6wVGdlts7whQV88jRlRUiJ8crEsyzpvO9e2bH5KPYT1b_hWPZScBj1qN0LNZAXCqTWqUqKRVjlNKCb7VZy1nbh4g2yYGTduFesrT8wrwpkamewGB_nfhUBCwJ8YnCGSuhTHXytpxOT3P84hIvtjdThV9HivPo4ldf3hcqvKy-WOCA2m4iV-5DAy2y_yz52k8w--72GKg1bKDpIz72Vz1Y3thZNv13vQMMMKtNsjKDcbhPEgzKKnl6ucDy88zr6GEu3oP1owe0Q&amp;source=gmail&amp;ust=1590576057622000&amp;usg=AFQjCNFJYIG2SiQRz8yXHuPsh96nGLUVhQ'><p>Daily deals</p></a>
                                        </td>
                                        <td class='m_-4380193512371063790promocat' style='text-align:center;width:15%'>
                                            <a href='http://email.mg.alipata.com/c/eJwtkEGPgyAQhX8NXhoNoqAePGhpu5u06aHby14Mi6xlK2AU1mR__UJjQsi8l4-Zx_Q1xxBWPJI1gghCDBGCmKQoSROckhJhVOZZRiilLcihGpIfpyRLuFHRoy7ZN6wqXjBWcliWhAiY93nJsyJjFSmKaKwf1k4gawA6-rOu6_beDV4q8yVHEU8Po8USiOyozWQ8T-3sBEDEWdUp0UunvCcUk-NmLsbNXLxAphfGrTSajV0glg3hTE1MDtpD4WsxxDFEHwj6NJj4K00_N9KKOfS_n2KA20O3P3b0cOveDg31-nJt37vmfL4BTKO5fopfqSfmxlX--YUMYeJrG7beG6WclpyFMLuL6d0ovH293KKeWVaDogWw2e0AQlrY1cxPX_kgwbifQg0bUNB_yxp6JQ' style='text-decoration:none;color:inherit' target='_blank' data-saferedirecturl='https://www.google.com/url?q=http://email.mg.alipata.com/c/eJwtkEGPgyAQhX8NXhoNoqAePGhpu5u06aHby14Mi6xlK2AU1mR__UJjQsi8l4-Zx_Q1xxBWPJI1gghCDBGCmKQoSROckhJhVOZZRiilLcihGpIfpyRLuFHRoy7ZN6wqXjBWcliWhAiY93nJsyJjFSmKaKwf1k4gawA6-rOu6_beDV4q8yVHEU8Po8USiOyozWQ8T-3sBEDEWdUp0UunvCcUk-NmLsbNXLxAphfGrTSajV0glg3hTE1MDtpD4WsxxDFEHwj6NJj4K00_N9KKOfS_n2KA20O3P3b0cOveDg31-nJt37vmfL4BTKO5fopfqSfmxlX--YUMYeJrG7beG6WclpyFMLuL6d0ovH293KKeWVaDogWw2e0AQlrY1cxPX_kgwbifQg0bUNB_yxp6JQ&amp;source=gmail&amp;ust=1590576057622000&amp;usg=AFQjCNGrOoDzQfTGxb2FCTIgEjxsHPlWiA'><p>Phones</p></a>
                                        </td>

                                        <td class='m_-4380193512371063790promocat' style='text-align:center;width:15%'>
                                            <a href='http://email.mg.alipata.com/c/eJwtkE-PwiAQxT8NvRgbOi39c-ihiroHjZu4Xrw0SNnKWqCpsE320y-YJoS8efkx85iu5gTjikeyBgwYEwyASZ5AnMQkyUsgUGZpmlNKNyjDqo9_nJIs5kZFj7rgZVexjGTV_RtwJfKCFSSvSsGqqoC7iIb6Ye2I0gbB3p95npf3rvelbzI6K3XQKN1rMxrPUjs5gSB3VrVKdNIp7wnF5LCYL-MmLt4g0y_GrTSaDW0gXgvCmRqZ7LWHwrfWmKwxfAH2SUjuryS5LaQVU-h_PawR2eza7b6lu0v7sWuor7fn02fbHI8XRGg01U_xK_XI3DDLP7-MPkx8b8LWW6OU05KzEGZ1Mp0bhLfPp0vUMctqVGwQblYrBKCFnc309MoHCcb1EDRuUEH_ARMSeQ0' style='text-decoration:none;color:inherit' target='_blank' data-saferedirecturl='https://www.google.com/url?q=http://email.mg.alipata.com/c/eJwtkE-PwiAQxT8NvRgbOi39c-ihiroHjZu4Xrw0SNnKWqCpsE320y-YJoS8efkx85iu5gTjikeyBgwYEwyASZ5AnMQkyUsgUGZpmlNKNyjDqo9_nJIs5kZFj7rgZVexjGTV_RtwJfKCFSSvSsGqqoC7iIb6Ye2I0gbB3p95npf3rvelbzI6K3XQKN1rMxrPUjs5gSB3VrVKdNIp7wnF5LCYL-MmLt4g0y_GrTSaDW0gXgvCmRqZ7LWHwrfWmKwxfAH2SUjuryS5LaQVU-h_PawR2eza7b6lu0v7sWuor7fn02fbHI8XRGg01U_xK_XI3DDLP7-MPkx8b8LWW6OU05KzEGZ1Mp0bhLfPp0vUMctqVGwQblYrBKCFnc309MoHCcb1EDRuUEH_ARMSeQ0&amp;source=gmail&amp;ust=1590576057622000&amp;usg=AFQjCNGwMRSekKn39d4EfE0VQHp_wdrn6g'><p>Computers</p></a>
                                        </td>
                                        <td class='m_-4380193512371063790promocat' style='text-align:center;width:15%'>
                                            <a href='http://email.mg.alipata.com/c/eJwtkMFuwjAMhp8mvaBWjtsEOPRQaGEH0A5sl12qkEYlo2mqklBpT78EIVmW_euz88ddKRnAVia6REAABojAOMWMZozyDTLcFHnO67rekQJMn_16o0UmrUluJQUu15wVUKii67DYInJawFaBul43FJOhvDk3kbwieAixLMt73vehdc9U-E7b9Kk7ZSOSH0Y72TBQu9krgtw70xrVaW-CpozQw1t8WD9L9QLF-BDSaTuKoY3E441IYSah-zFA8W8psBTwCyHYYTwkSn_epFNz3P99TAnbNe3-0NbNpf1oqjr2p2bfVqfThbA6mcu7eupxEn5Y9F-4SB9ffJ3DlXtrjB-1FNHM6mw7P6ggf54vSSecKMl6R6BarQjiqNxi53uogpEofB9jDRVZ1_90QXnM' style='text-decoration:none;color:inherit' target='_blank' data-saferedirecturl='https://www.google.com/url?q=http://email.mg.alipata.com/c/eJwtkMFuwjAMhp8mvaBWjtsEOPRQaGEH0A5sl12qkEYlo2mqklBpT78EIVmW_euz88ddKRnAVia6REAABojAOMWMZozyDTLcFHnO67rekQJMn_16o0UmrUluJQUu15wVUKii67DYInJawFaBul43FJOhvDk3kbwieAixLMt73vehdc9U-E7b9Kk7ZSOSH0Y72TBQu9krgtw70xrVaW-CpozQw1t8WD9L9QLF-BDSaTuKoY3E441IYSah-zFA8W8psBTwCyHYYTwkSn_epFNz3P99TAnbNe3-0NbNpf1oqjr2p2bfVqfThbA6mcu7eupxEn5Y9F-4SB9ffJ3DlXtrjB-1FNHM6mw7P6ggf54vSSecKMl6R6BarQjiqNxi53uogpEofB9jDRVZ1_90QXnM&amp;source=gmail&amp;ust=1590576057622000&amp;usg=AFQjCNH_Io52Kmnmmod51nNE_5Fjg0zjPA'><p>Electronics</p></a>
                                        </td>
                                        <td class='m_-4380193512371063790promocat' style='text-align:center;width:15%'>
                                            <a href='http://email.mg.alipata.com/c/eJwtkEGPgjAQhX9NuRjIMLWoBw5oUQ8aD66XvZACBbtSSrBdkv31WwxJM5n38rV9M3VaMYBdFagUAQEYIAJLYoziiMXJFhlu15QmnPM9WYNuox-nlYgqo4NnumElgiiTZkepqHe0KUFCk0AjJNISMejSp7UDoRnBoz_TNC33Xevl02gZdupX9bMi9NibwXia29FJgomzutCyVk57T2qhusV8GzdW8gOK_i0qq0wvumIm3gtSCT0I1fYemgcLgYWAXwg-C0t8iePvhbRynN9_nELC9nlxOBY8vxfnPONen2_XvMgulzthPBjTl_RhB-G6Sf35dbTzj59d2PRgtHa9qsQcZnU1teukt2_Xe1ALK1Ky2RPIViuC2Es7mfHlOx9kNh6nuYeMbPg_WHp56A' style='text-decoration:none;color:inherit' target='_blank' data-saferedirecturl='https://www.google.com/url?q=http://email.mg.alipata.com/c/eJwtkEGPgjAQhX9NuRjIMLWoBw5oUQ8aD66XvZACBbtSSrBdkv31WwxJM5n38rV9M3VaMYBdFagUAQEYIAJLYoziiMXJFhlu15QmnPM9WYNuox-nlYgqo4NnumElgiiTZkepqHe0KUFCk0AjJNISMejSp7UDoRnBoz_TNC33Xevl02gZdupX9bMi9NibwXia29FJgomzutCyVk57T2qhusV8GzdW8gOK_i0qq0wvumIm3gtSCT0I1fYemgcLgYWAXwg-C0t8iePvhbRynN9_nELC9nlxOBY8vxfnPONen2_XvMgulzthPBjTl_RhB-G6Sf35dbTzj59d2PRgtHa9qsQcZnU1teukt2_Xe1ALK1Ky2RPIViuC2Es7mfHlOx9kNh6nuYeMbPg_WHp56A&amp;source=gmail&amp;ust=1590576057622000&amp;usg=AFQjCNH9g4OifnG9GaQPnb-BIchdgJPMog'><p>Home appliances</p></a>
                                        </td>
                                        <td class='m_-4380193512371063790promocat' style='text-align:center;width:15%'>
                                            <a href='http://email.mg.alipata.com/c/eJwtkMGOgyAQhp8GL40Gx4L24MGWtnto00O3l70YRGrZihiFNdmnX9iYkMnMn4-Zf6YtBcF4JyJVAgaMCQbAhKaQpAlJaQEEim2WUcbYHm2x7pJvpxVPhNHRq2wa_Cx2hOYUBBWA0zSHVjYAuwKKNn9GffmydpxRViE4-bcsy9rAdb6cRykU7-NxUkIGIjsNZjQjypidnFeos7rWslVOe01qrvpVnI2b_J8A8mHmwioz8L4OxLwiguuRq27wUNgtxiTG8AnYuyHUhzT9Wkkrp9D_cY4R2R_rw6lmx3v9cayYr9mN1dXlckeERVP5lj9qGLnrF_XrD9KFgf_XsOXBaO0GJXjwsrma1vXSy7frPWq55SXK9whXmw0CGKRdzPT2mfcRhMc55LhCOfsDxcZ6JQ' style='text-decoration:none;color:inherit' target='_blank' data-saferedirecturl='https://www.google.com/url?q=http://email.mg.alipata.com/c/eJwtkMGOgyAQhp8GL40Gx4L24MGWtnto00O3l70YRGrZihiFNdmnX9iYkMnMn4-Zf6YtBcF4JyJVAgaMCQbAhKaQpAlJaQEEim2WUcbYHm2x7pJvpxVPhNHRq2wa_Cx2hOYUBBWA0zSHVjYAuwKKNn9GffmydpxRViE4-bcsy9rAdb6cRykU7-NxUkIGIjsNZjQjypidnFeos7rWslVOe01qrvpVnI2b_J8A8mHmwioz8L4OxLwiguuRq27wUNgtxiTG8AnYuyHUhzT9Wkkrp9D_cY4R2R_rw6lmx3v9cayYr9mN1dXlckeERVP5lj9qGLnrF_XrD9KFgf_XsOXBaO0GJXjwsrma1vXSy7frPWq55SXK9whXmw0CGKRdzPT2mfcRhMc55LhCOfsDxcZ6JQ&amp;source=gmail&amp;ust=1590576057622000&amp;usg=AFQjCNFHHe8j3qATqfAvzryoznAw_fuK2g'><p>Fashion</p></a>
                                        </td>
                                    </tr>
                                </tbody></table>
                                <table class='m_-4380193512371063790promocatmobile' width='100%' cellspacing='0' cellpadding='0' style='background:#fff;padding-left:5px;font-size:0px;border-bottom:1px solid lightgrey;border-top:1px solid lightgrey;display:none;overflow:hidden'>
                                    <tbody><tr>
                                        <td class='m_-4380193512371063790promocatmobile' style='text-align:center;width:19%'>
                                            <a href='http://email.mg.alipata.com/c/eJwtkMFugzAMhp8mXCqQCQ2FAwfatN2hVQ9dL7ugEALNSgiCZGh7-iUVkmXZvz47f9wUnADkPJAFBgxAAGMgaYyjOCJxmmGCs22SpJTSPdqC6qJvqySLuFbBs-AiaUWbpywhdZ2nCWkhg6wVGdlts7whQV88jRlRUiJ8crEsyzpvO9e2bH5KPYT1b_hWPZScBj1qN0LNZAXCqTWqUqKRVjlNKCb7VZy1nbh4g2yYGTduFesrT8wrwpkamewGB_nfhUBCwJ8YnCGSuhTHXytpxOT3P84hIvtjdThV9HivPo4ldf3hcqvKy-WOCA2m4iV-5DAy2y_yz52k8w--72GKg1bKDpIz72Vz1Y3thZNv13vQMMMKtNsjKDcbhPEgzKKnl6ucDy88zr6GEu3oP1owe0Q' style='text-decoration:none;color:inherit' target='_blank' data-saferedirecturl='https://www.google.com/url?q=http://email.mg.alipata.com/c/eJwtkMFugzAMhp8mXCqQCQ2FAwfatN2hVQ9dL7ugEALNSgiCZGh7-iUVkmXZvz47f9wUnADkPJAFBgxAAGMgaYyjOCJxmmGCs22SpJTSPdqC6qJvqySLuFbBs-AiaUWbpywhdZ2nCWkhg6wVGdlts7whQV88jRlRUiJ8crEsyzpvO9e2bH5KPYT1b_hWPZScBj1qN0LNZAXCqTWqUqKRVjlNKCb7VZy1nbh4g2yYGTduFesrT8wrwpkamewGB_nfhUBCwJ8YnCGSuhTHXytpxOT3P84hIvtjdThV9HivPo4ldf3hcqvKy-WOCA2m4iV-5DAy2y_yz52k8w--72GKg1bKDpIz72Vz1Y3thZNv13vQMMMKtNsjKDcbhPEgzKKnl6ucDy88zr6GEu3oP1owe0Q&amp;source=gmail&amp;ust=1590576057622000&amp;usg=AFQjCNFJYIG2SiQRz8yXHuPsh96nGLUVhQ'><p>Fashion</p></a>
                                        </td>
                                        <td class='m_-4380193512371063790promocatmobile' style='text-align:center;width:19%'>
                                            <a href='http://email.mg.alipata.com/c/eJwtkEGPgyAQhX8NXhoNoqAePGhpu5u06aHby14Mi6xlK2AU1mR__UJjQsi8l4-Zx_Q1xxBWPJI1gghCDBGCmKQoSROckhJhVOZZRiilLcihGpIfpyRLuFHRoy7ZN6wqXjBWcliWhAiY93nJsyJjFSmKaKwf1k4gawA6-rOu6_beDV4q8yVHEU8Po8USiOyozWQ8T-3sBEDEWdUp0UunvCcUk-NmLsbNXLxAphfGrTSajV0glg3hTE1MDtpD4WsxxDFEHwj6NJj4K00_N9KKOfS_n2KA20O3P3b0cOveDg31-nJt37vmfL4BTKO5fopfqSfmxlX--YUMYeJrG7beG6WclpyFMLuL6d0ovH293KKeWVaDogWw2e0AQlrY1cxPX_kgwbifQg0bUNB_yxp6JQ' style='text-decoration:none;color:inherit' target='_blank' data-saferedirecturl='https://www.google.com/url?q=http://email.mg.alipata.com/c/eJwtkEGPgyAQhX8NXhoNoqAePGhpu5u06aHby14Mi6xlK2AU1mR__UJjQsi8l4-Zx_Q1xxBWPJI1gghCDBGCmKQoSROckhJhVOZZRiilLcihGpIfpyRLuFHRoy7ZN6wqXjBWcliWhAiY93nJsyJjFSmKaKwf1k4gawA6-rOu6_beDV4q8yVHEU8Po8USiOyozWQ8T-3sBEDEWdUp0UunvCcUk-NmLsbNXLxAphfGrTSajV0glg3hTE1MDtpD4WsxxDFEHwj6NJj4K00_N9KKOfS_n2KA20O3P3b0cOveDg31-nJt37vmfL4BTKO5fopfqSfmxlX--YUMYeJrG7beG6WclpyFMLuL6d0ovH293KKeWVaDogWw2e0AQlrY1cxPX_kgwbifQg0bUNB_yxp6JQ&amp;source=gmail&amp;ust=1590576057622000&amp;usg=AFQjCNGrOoDzQfTGxb2FCTIgEjxsHPlWiA'><p>Phones</p></a>
                                        </td>

                                        <td class='m_-4380193512371063790promocatmobile' style='text-align:center;width:19%'>
                                            <a href='http://email.mg.alipata.com/c/eJwtkE-PwiAQxT8NvRgbOi39c-ihiroHjZu4Xrw0SNnKWqCpsE320y-YJoS8efkx85iu5gTjikeyBgwYEwyASZ5AnMQkyUsgUGZpmlNKNyjDqo9_nJIs5kZFj7rgZVexjGTV_RtwJfKCFSSvSsGqqoC7iIb6Ye2I0gbB3p95npf3rvelbzI6K3XQKN1rMxrPUjs5gSB3VrVKdNIp7wnF5LCYL-MmLt4g0y_GrTSaDW0gXgvCmRqZ7LWHwrfWmKwxfAH2SUjuryS5LaQVU-h_PawR2eza7b6lu0v7sWuor7fn02fbHI8XRGg01U_xK_XI3DDLP7-MPkx8b8LWW6OU05KzEGZ1Mp0bhLfPp0vUMctqVGwQblYrBKCFnc309MoHCcb1EDRuUEH_ARMSeQ0' style='text-decoration:none;color:inherit' target='_blank' data-saferedirecturl='https://www.google.com/url?q=http://email.mg.alipata.com/c/eJwtkE-PwiAQxT8NvRgbOi39c-ihiroHjZu4Xrw0SNnKWqCpsE320y-YJoS8efkx85iu5gTjikeyBgwYEwyASZ5AnMQkyUsgUGZpmlNKNyjDqo9_nJIs5kZFj7rgZVexjGTV_RtwJfKCFSSvSsGqqoC7iIb6Ye2I0gbB3p95npf3rvelbzI6K3XQKN1rMxrPUjs5gSB3VrVKdNIp7wnF5LCYL-MmLt4g0y_GrTSaDW0gXgvCmRqZ7LWHwrfWmKwxfAH2SUjuryS5LaQVU-h_PawR2eza7b6lu0v7sWuor7fn02fbHI8XRGg01U_xK_XI3DDLP7-MPkx8b8LWW6OU05KzEGZ1Mp0bhLfPp0vUMctqVGwQblYrBKCFnc309MoHCcb1EDRuUEH_ARMSeQ0&amp;source=gmail&amp;ust=1590576057622000&amp;usg=AFQjCNGwMRSekKn39d4EfE0VQHp_wdrn6g'><p>Computers</p></a>
                                        </td>
                                        <td class='m_-4380193512371063790promocatmobile' style='text-align:center;width:19%'>
                                            <a href='http://email.mg.alipata.com/c/eJwtkMFuwjAMhp8mvaBWjtsEOPRQaGEH0A5sl12qkEYlo2mqklBpT78EIVmW_euz88ddKRnAVia6REAABojAOMWMZozyDTLcFHnO67rekQJMn_16o0UmrUluJQUu15wVUKii67DYInJawFaBul43FJOhvDk3kbwieAixLMt73vehdc9U-E7b9Kk7ZSOSH0Y72TBQu9krgtw70xrVaW-CpozQw1t8WD9L9QLF-BDSaTuKoY3E441IYSah-zFA8W8psBTwCyHYYTwkSn_epFNz3P99TAnbNe3-0NbNpf1oqjr2p2bfVqfThbA6mcu7eupxEn5Y9F-4SB9ffJ3DlXtrjB-1FNHM6mw7P6ggf54vSSecKMl6R6BarQjiqNxi53uogpEofB9jDRVZ1_90QXnM' style='text-decoration:none;color:inherit' target='_blank' data-saferedirecturl='https://www.google.com/url?q=http://email.mg.alipata.com/c/eJwtkMFuwjAMhp8mvaBWjtsEOPRQaGEH0A5sl12qkEYlo2mqklBpT78EIVmW_euz88ddKRnAVia6REAABojAOMWMZozyDTLcFHnO67rekQJMn_16o0UmrUluJQUu15wVUKii67DYInJawFaBul43FJOhvDk3kbwieAixLMt73vehdc9U-E7b9Kk7ZSOSH0Y72TBQu9krgtw70xrVaW-CpozQw1t8WD9L9QLF-BDSaTuKoY3E441IYSah-zFA8W8psBTwCyHYYTwkSn_epFNz3P99TAnbNe3-0NbNpf1oqjr2p2bfVqfThbA6mcu7eupxEn5Y9F-4SB9ffJ3DlXtrjB-1FNHM6mw7P6ggf54vSSecKMl6R6BarQjiqNxi53uogpEofB9jDRVZ1_90QXnM&amp;source=gmail&amp;ust=1590576057622000&amp;usg=AFQjCNH_Io52Kmnmmod51nNE_5Fjg0zjPA'><p>Electronics</p></a>
                                        </td>
                                        <td class='m_-4380193512371063790promocatmobile' style='text-align:center;color:#f49719;width:19%'>
                                            <a href='http://email.mg.alipata.com/c/eJwtkMGOgyAQhp8GL40Gx4L24MGWtnto00O3l70YRGrZihiFNdmnX9iYkMnMn4-Zf6YtBcF4JyJVAgaMCQbAhKaQpAlJaQEEim2WUcbYHm2x7pJvpxVPhNHRq2wa_Cx2hOYUBBWA0zSHVjYAuwKKNn9GffmydpxRViE4-bcsy9rAdb6cRykU7-NxUkIGIjsNZjQjypidnFeos7rWslVOe01qrvpVnI2b_J8A8mHmwioz8L4OxLwiguuRq27wUNgtxiTG8AnYuyHUhzT9Wkkrp9D_cY4R2R_rw6lmx3v9cayYr9mN1dXlckeERVP5lj9qGLnrF_XrD9KFgf_XsOXBaO0GJXjwsrma1vXSy7frPWq55SXK9whXmw0CGKRdzPT2mfcRhMc55LhCOfsDxcZ6JQ' style='text-decoration:none;color:inherit' target='_blank' data-saferedirecturl='https://www.google.com/url?q=http://email.mg.alipata.com/c/eJwtkMGOgyAQhp8GL40Gx4L24MGWtnto00O3l70YRGrZihiFNdmnX9iYkMnMn4-Zf6YtBcF4JyJVAgaMCQbAhKaQpAlJaQEEim2WUcbYHm2x7pJvpxVPhNHRq2wa_Cx2hOYUBBWA0zSHVjYAuwKKNn9GffmydpxRViE4-bcsy9rAdb6cRykU7-NxUkIGIjsNZjQjypidnFeos7rWslVOe01qrvpVnI2b_J8A8mHmwioz8L4OxLwiguuRq27wUNgtxiTG8AnYuyHUhzT9Wkkrp9D_cY4R2R_rw6lmx3v9cayYr9mN1dXlckeERVP5lj9qGLnrF_XrD9KFgf_XsOXBaO0GJXjwsrma1vXSy7frPWq55SXK9whXmw0CGKRdzPT2mfcRhMc55LhCOfsDxcZ6JQ&amp;source=gmail&amp;ust=1590576057622000&amp;usg=AFQjCNFHHe8j3qATqfAvzryoznAw_fuK2g'><p>Daily deals</p></a>
                                        </td>
                                    </tr>
                                </tbody></table>

                                <table class='m_-4380193512371063790bodycontent' width='100%' cellspacing='0' style='padding-top:15px'>
                                    <tbody><tr>
                                        <td class='m_-4380193512371063790bodycontent_cell' style='background-color:#ffffff;color:#565656;padding:15px 15px 15px 15px; font-size: 15px;' width='100%'>
                                       <span style='font-size: 1.2em;'>Hi kevin <img width='25' style='' src='http://alipata.com/images/icon/cm1.png'></span>
<p style='font-size: 1.2em;'>
Thank you for your Purchase on Alipata!. <br>Your order <b style='color:blue;'>&#8470; :$orderNo</b>, has been successfully confirmed.
</p><p>
It will be packaged and shipped as soon as possible. Once the item(s) is out for delivery or available for pick-up you will receive a notification from us.
</p><p>
Thank you for shopping on Alipata.
    
                                                  <a href='http://email.mg.alipata.com/c/eJwtjs1uwyAQhJ8GLpas9dr458DBqZWcohyqPgAB7NAYiBwIUZ6-JKo00nw7h5lVXDKAQVLDERCAASKwtsKyKlnV9siwb-q6naZpRxqwS_kbrRGl9JZeuMQZu_o8a-wGBb2Q6twwHOaGQYvYK7rySwi3O6lHgvuslNJ_QVzyKeM9eKu3jH5THzdO6Wd2uvGrfhh3E3FN5pW3FyvM-hkO_MtbG52RIhjviqNXcdU5Ph2_qRJBcNLtCIxFQRCdDslv10z5i3fwc3gzjKSb_gCbCEva' style='color:#0000ee' target='_blank' data-saferedirecturl='https://www.google.com/url?q=http://email.mg.alipata.com/c/eJwtjs1uwyAQhJ8GLpas9dr458DBqZWcohyqPgAB7NAYiBwIUZ6-JKo00nw7h5lVXDKAQVLDERCAASKwtsKyKlnV9siwb-q6naZpRxqwS_kbrRGl9JZeuMQZu_o8a-wGBb2Q6twwHOaGQYvYK7rySwi3O6lHgvuslNJ_QVzyKeM9eKu3jH5THzdO6Wd2uvGrfhh3E3FN5pW3FyvM-hkO_MtbG52RIhjviqNXcdU5Ph2_qRJBcNLtCIxFQRCdDslv10z5i3fwc3gzjKSb_gCbCEva&amp;source=gmail&amp;ust=1590576057623000&amp;usg=AFQjCNEBWul_mWKr_HtbXtg_Wk8LGiP_jw'><img src='https://ci3.googleusercontent.com/proxy/DI694ObPHSojrPhLoE25dFr_Y17lCcSDRXCt96nLq9fv3_vPeos2A9ZL6LC1eifDi2u92t3I2CkibAunfBnozSxV31BNv9k6Fmyp9aH75pN8Yyexf20O5s_aUK6vW-1rYK20WeUtBLLhtPbC=s0-d-e1-ft#https://alipata.co/nl-templates-nigeria/admin/images/newTemplates/Tracking_toolbar_2_EN.PNG' alt='TrackingToolbar' style='width:100%' class='CToWUd'></a>                                             </p><p>
      <b>Please note:</b>
    </p><p></p><ul>
      <li>If you ordered for multiple items, you may receive them on different days. This is because they are sold by different sellers on our platform and we want to make each item available to you as soon as possible after receiving it.</li>
      </ul>
                     
                                            <p></p>

                            <div style='padding:0 0; '>
                                                <div style='padding:0 0'>
                                                    <div style='display:table;border-collapse:separate;width:100%;border-spacing:2px; '>
                                                        <div style='display:table-row'>
                                                            <div style='width:50%;display:table-cell;background-color:#fff;border:1px solid #e2e8e9;border-collapse:collapse;vertical-align:top; border-radius: 5px;'>
                                                                <p style='background-color:#f8f8f8;font-weight:bold;margin-top:0;margin-bottom:0px;padding:3px;vertical-align:middle'>Estimated delivery date(s)</p>
                                                                <p style='padding-left:3px;margin-top:1px'>Check our <a href='http://email.mg.alipata.com/c/eJwtkEGPgyAQhX8NXhoNjsXqwYOubU9NN1t72YuhSC1bAaNQs_vrFxoTMrx5-TI8pisYwThngSgAA8YEA2CSxhDFEYnTDAhk2yRJ67qu0BbLPvqxUtCIaRk8Ct7lHc4ovecpBpJDAlmecAY3fqNbnt6DoXgYM84oKREc3FmWZR1ge9d2fBAvPv2GRkgnFfdUclB61CNKajNZ56TWyFbyTljpPC6pGFZz1nZi_A1SNVNmhFZ0aD0xrwijcqSiVw7y_wsxCTE0gF0ikroSx98rafjk5yNSXY-hq_u2Kdt6f2k_z1-N6y-Nv-pgKp78JdRI7bCIP7eT3r_3XogpPrSUVglGfZTNSXd24M4-ny5BRw0t0K5CuNxsEIDiZtHT0ykXwxvXo9e4RLv6H7uWfHI' style='color:#0000ee' target='_blank' data-saferedirecturl='https://www.google.com/url?q=http://email.mg.alipata.com/c/eJwtkEGPgyAQhX8NXhoNjsXqwYOubU9NN1t72YuhSC1bAaNQs_vrFxoTMrx5-TI8pisYwThngSgAA8YEA2CSxhDFEYnTDAhk2yRJ67qu0BbLPvqxUtCIaRk8Ct7lHc4ovecpBpJDAlmecAY3fqNbnt6DoXgYM84oKREc3FmWZR1ge9d2fBAvPv2GRkgnFfdUclB61CNKajNZ56TWyFbyTljpPC6pGFZz1nZi_A1SNVNmhFZ0aD0xrwijcqSiVw7y_wsxCTE0gF0ikroSx98rafjk5yNSXY-hq_u2Kdt6f2k_z1-N6y-Nv-pgKp78JdRI7bCIP7eT3r_3XogpPrSUVglGfZTNSXd24M4-ny5BRw0t0K5CuNxsEIDiZtHT0ykXwxvXo9e4RLv6H7uWfHI&amp;source=gmail&amp;ust=1590576057623000&amp;usg=AFQjCNGLMbP-e3wLIVZ5x483d5JmaUdx6g'>delivery information page</a></p>
                                                            </div>
                                                            <div style='width:50%;display:table-cell;background-color:#fff;border:1px solid #e2e8e9;border-collapse:collapse;vertical-align:top; border-radius: 5px;'>
                                                                <p style='background-color:#f8f8f8;font-weight:bold;margin-top:0;margin-bottom:0px;padding:3px;vertical-align:middle;'>Delivery method</p>
                                                                <p style='padding-left:3px;margin-top:1px'>
                                                                         Delivery to Your Home or Office
                                                                    </p>
                                                            </div>

                                                        </div>
                                                        <div style='display:table-row'>
                                                            <div style='width:50%;display:table-cell;background-color:#fff;border:1px solid #e2e8e9;border-collapse:collapse;vertical-align:top;border-radius: 5px;'>
                                                                <p style='background-color:#f8f8f8;font-weight:bold;margin-top:0;margin-bottom:0px;padding:3px;vertical-align:middle'>Recipient details</p>
                                                                <p style='padding-left:3px;margin-top:1px'>
                                                                    kevin paul
                                                                    +256757729688</p>
                                                            </div>
                                                            <div style='width:50%;display:table-cell;background-color:#fff;border:1px solid #e2e8e9;border-collapse:collapse;vertical-align:top; border-radius: 5px;'>
                                                                <p style='background-color:#f8f8f8;font-weight:bold;margin-top:0;margin-bottom:0px;padding:3px;vertical-align:middle'>Delivery address</p>
                                                                <p style='padding-left:3px;margin-top:1px'>Buziga-katuuso 
                                                                                                                            
    Buziga
                                                                </p>
                                                            </div>

                                                        </div>
                                                    </div>

                                                </div>
                                            </div>
                                            


                                            <table class='m_-4380193512371063790orderinfotable' style='border:1px solid #ccc;margin:0;padding:0;width:100%;table-layout:fixed; border-radius: 5px;'>
                                                <caption class='m_-4380193512371063790orderinfocaption' style='font-weight:bold;text-align:left;padding-top:10px'>Order Summary:</caption>
                                                <thead class='m_-4380193512371063790orderinfohead' style='text-align:center'>
                                                    <tr class='m_-4380193512371063790orderinfohead' style='background:#f8f8f8;border:1px solid #e2e8e9;text-transform:uppercase'>
                                                        <th scope='col' style='width:15%'></th>
                                                        <th scope='col' style='width:50%'>Item</th>
                                                        <th scope='col' style='width:15%'>Quantity</th>
                                                        <th scope='col' style='width:15%'>Price</th>
                                                    </tr>
                                                </thead>
                                                <tbody>";


if(isset($_SESSION["products"]) && count($_SESSION["products"])>0){
$total = 0;
$list_tax = '';           
$cart_box = '';
foreach($_SESSION["products"] as $product){
$product_name = $product["product_name"];
$product_quantity = $product["product_quantity"];
$product_price = $product["Price"];
$product_id = $product["product_id"];
$product_color = $product["product_color"];         
$item_price = sprintf("%01.2f",($product_price * $product_quantity));
include("config/connection.php");
$sql = "SELECT image_path, product_id FROM product_images WHERE product_id='$product_id'";
$result = $conn->query($sql);
$row = $result->fetch_assoc();     
$product_image="http://alipata.com/admin/".$row["image_path"];  

$Products.="
<tr class='m_-4380193512371063790orderinfotr' style='border:1px solid #e2e8e9;text-align:center; font-size:12px;'>
<td class='m_-4380193512371063790orderinfotd'>
<center class='m_-4380193512371063790itemImgCenter' style='overflow:hidden;max-width:100% small'>
<img width='80' height='80' data-toggle='tooltip' ata-placement='top' class='img-responsive img-fluid float-left pr-2' src='$product_image' data-src='' alt='$product_name' title='$product_name' data-placeholder=''>
</center>
</td>
<td class='m_-4380193512371063790orderinfotd'><span class='m_-4380193512371063790itemlabel' style='display:none;overflow:hidden;font-size:0px'>Item</span>$product_name</td>
<td class='m_-4380193512371063790orderinfotd'><span class='m_-4380193512371063790itemlabel' style='display:none;overflow:hidden;font-size:0px'>Quantity</span>$product_quantity</td>
<td class='m_-4380193512371063790orderinfotd' style='text-align:right'><span class='m_-4380193512371063790itemlabel' style='display:none;overflow:hidden;font-size:0px'>Price</span> UGX $product_price</td>
</tr>";

        $subtotal = ($product_price * $product_quantity);
        $total = ($total + $subtotal);
    }   
    include("inc/config.inc.php");
     $shipping_cost=count($_SESSION["products"])*$shipping_cost;
    $grand_total = $total + $shipping_cost;
    foreach($taxes as $key => $value){
            $tax_amount = round($total * ($value / 100));
            $tax_item[$key] = $tax_amount;
            $grand_total = $grand_total + $tax_amount; 
    }   
    foreach($tax_item as $key => $value){
        $list_tax .= $key. ' : '. $currency. sprintf("%01.2f", $value).'<br />';
    }   

    $cart_box .= "<span>$shipping_cost  $list_tax <hr>Payable Amount : $currency ".sprintf("%01.2f", $grand_total)."</span>";  
}

$grand_total=number_format($grand_total, 0, '.', ',');
$shipping_cost=number_format($shipping_cost, 0, '.', ',');






$htmlContent_end=" </tbody>
                                            </table>

                                            
                                           <table style='width:100%;border:1px solid #ccc;margin-top:5px;table-layout:auto'>
                                                <tbody><tr><td style='font-weight:bold!important;text-transform:uppercase!important'>Shipping Cost</td><td style='text-align:right'>$currency $shipping_cost</td></tr>
                                                   <tr>
                                                        <td style='font-weight:bold!important;text-transform:uppercase!important'>Shipping Discount</td>
                                                        <td style='text-align:right'>UGX 0</td>
                                                    </tr>
                                                <tr><td style='font-weight:bold!important;text-transform:uppercase!important'>Discount</td><td style='text-align:right'>UGX 0</td></tr>
                                                <tr><td style='font-weight:bold!important;text-transform:uppercase!important'>TOTAL</td><td style='text-align:right; font-size: 1.2em; font-weight: 700; color: #ff4d01;'> $currency $grand_total</td></tr>
                                                <tr><td style='font-weight:bold!important;text-transform:uppercase!important'>Payment Method</td><td style='text-align:right'>
                                                        Payment on delivery/pick-up
</td></tr>
                                            </tbody></table>
                                        <?php } ?>
                                            
                                            <p>If you would like to know more about our services, please also refer to these <a href='http://email.mg.alipata.com/c/eJwtjUGLwyAUhH-NXgLh-YxJc_CQbtieSg_L_gBrbGKrMbRaob--dlkYeDMDb75JagHQa2olAgIIQATRMqxZLVi7Q4G7hvN2HMc9acDP9TV5q2odPF3K70Wf-Zk1DDn0HaoL6r5RwAXT3OiJOrnEuD0IHwh-F-Wc_wfSXOJi3FYOvcubedp1U8ll-yqc2Svr_iBRfgXv02q1ijas1TFMyZlSn44_dFJRSdLtCQxVRRBXE3O434orxE_xe_h4GEg3vgGSIkS4' style='color:#0000ee' target='_blank' data-saferedirecturl='https://www.google.com/url?q=http://email.mg.alipata.com/c/eJwtjUGLwyAUhH-NXgLh-YxJc_CQbtieSg_L_gBrbGKrMbRaob--dlkYeDMDb75JagHQa2olAgIIQATRMqxZLVi7Q4G7hvN2HMc9acDP9TV5q2odPF3K70Wf-Zk1DDn0HaoL6r5RwAXT3OiJOrnEuD0IHwh-F-Wc_wfSXOJi3FYOvcubedp1U8ll-yqc2Svr_iBRfgXv02q1ijas1TFMyZlSn44_dFJRSdLtCQxVRRBXE3O434orxE_xe_h4GEg3vgGSIkS4&amp;source=gmail&amp;ust=1590576057623000&amp;usg=AFQjCNFW9W8VECGTGwcC9Wu1lEnkxeDlJw'>FAQs</a> from our customers.</p>

                                                 <img src='http://alipata.com/images/media/safety.jpg' alt='SafetyProcedures' style='width:100%' class='CToWUd'>

                                                 
                                            
                                              <p>
                                                
                                              </p>
                                            
                                            <p>Happy Shopping!</p>

                                            <p>Warm Regards,</p>
                                            <img class='m_-4380193512371063790signature CToWUd' src='http://alipata.com/images/media/alipatasignature.png' alt='Tracker' style='padding-left:1px;width:25%'>
                                            <p>alipata Uganda Team</p>
                                            <p style='font-weight:bold'>Got any questions?</p>
                                            <ul style='padding-left:0px'>
                                                <li style='margin-left:1.2em'>Have a look at our <a href='http://email.mg.alipata.com/c/eJwtjUGLwyAUhH-NXgLh-YxJc_CQbtieSg_L_gBrbGKrMbRaob--dlkYeDMDb75JagHQa2olAgIIQATRMqxZLVi7Q4G7hvN2HMc9acDP9TV5q2odPF3K70Wf-Zk1DDn0HaoL6r5RwAXT3OiJOrnEuD0IHwh-F-Wc_wfSXOJi3FYOvcubedp1U8ll-yqc2Svr_iBRfgXv02q1ijas1TFMyZlSn44_dFJRSdLtCQxVRRBXE3O434orxE_xe_h4GEg3vgGSIkS4' style='color:#0000ee' target='_blank' data-saferedirecturl='https://www.google.com/url?q=http://email.mg.alipata.com/c/eJwtjUGLwyAUhH-NXgLh-YxJc_CQbtieSg_L_gBrbGKrMbRaob--dlkYeDMDb75JagHQa2olAgIIQATRMqxZLVi7Q4G7hvN2HMc9acDP9TV5q2odPF3K70Wf-Zk1DDn0HaoL6r5RwAXT3OiJOrnEuD0IHwh-F-Wc_wfSXOJi3FYOvcubedp1U8ll-yqc2Svr_iBRfgXv02q1ijas1TFMyZlSn44_dFJRSdLtCQxVRRBXE3O434orxE_xe_h4GEg3vgGSIkS4&amp;source=gmail&amp;ust=1590576057623000&amp;usg=AFQjCNFW9W8VECGTGwcC9Wu1lEnkxeDlJw'>Help</a> page</li>
                                                
                                                <li style='margin-left:1.2em'>To get in touch <a href='http://email.mg.alipata.com/c/eJwtjcFuwyAQRL8GLpasZTGOfeDg1EpOUQ9VPmCFkUNsIEqhSP36kirSHN7MYd6ijQIYDXcaAQEUIILqBbaiVaIfUOHQSdnP83xkHfi1vWfvqDXR85seoUOBBOMwGEtSKUukyKAUizQdId_1LaXHN5MTw1NNKeV9kNdaTQyJTKrEn3qzPy48KO_F_VbV6snt_56kP6L3OThDycXQXOKSd1vnz8sXXyiRZocjg6lpGGKwqcTnVqlKX8P1_GKY2GH-A2DVRco' style='color:#0000ee' target='_blank' data-saferedirecturl='https://www.google.com/url?q=http://email.mg.alipata.com/c/eJwtjcFuwyAQRL8GLpasZTGOfeDg1EpOUQ9VPmCFkUNsIEqhSP36kirSHN7MYd6ijQIYDXcaAQEUIILqBbaiVaIfUOHQSdnP83xkHfi1vWfvqDXR85seoUOBBOMwGEtSKUukyKAUizQdId_1LaXHN5MTw1NNKeV9kNdaTQyJTKrEn3qzPy48KO_F_VbV6snt_56kP6L3OThDycXQXOKSd1vnz8sXXyiRZocjg6lpGGKwqcTnVqlKX8P1_GKY2GH-A2DVRco&amp;source=gmail&amp;ust=1590576057623000&amp;usg=AFQjCNG4di2c3AQpxsc5SfsWX4Q82vmudw'>fill our Contact Us form</a></li>
                                                <li style='margin-left:1.2em'>We are here for you:  Monday - Friday 8:30am to 5:00pm</li>
                                            </ul>
                                        <p></p><p></p><p></p><p></p></td>
                                    </tr>
                                </tbody></table>
  
         <table style='border:0px solid #ccc;margin:0;padding:0;width:100%;table-layout:fixed;min-width:100%;margin:0 auto'>               <tbody>
      <tr style='border:0px solid #e2e8e9;text-align:center'>
          
      </tr>
  </tbody>
</table>    
  
<table width='100%' cellspacing='0' style='padding:0 0 1% 0.5%!important'>
                                    <tbody><tr>
                                        <td>                                          
                                        </td>
                                    </tr>
                                </tbody></table>
                                <table class='m_-4380193512371063790footer' width='96%' cellspacing='0' style='margin-bottom:15px;padding:0 0 0 4%!important'>
                                    <tbody><tr style='display:block'>
                                        <td style='width:50%'>
                                            <table>
                                                <tbody><tr>
                                                    <td>&nbsp;</td>
                                                </tr>
                                                <tr>
                                                    <td>
                                                        <a href='http://email.mg.alipata.com/c/eJw1kMGKwyAUAL_GXErCi4lJesghbWhPpYVtL3spRm1rGjVE3cJ-_WrpgshjGGR8vGUEYM0S2WLAAAQwBlLlOMszklcNJrgpi6Lq-36DSlD3bPRK0owZlTxaJggZhoZXxSBEwWu4DbTM180AAHXdNMnUPpybLSo6hHfh0HnOKB-9dfGFAMbKsWdxHT0po7bTZjYzKnq3eIFw5Z26KsGlV4EJReX0gdb4hYm3SLWlzEmj6XSNhg3Kx2JUzVTedfDi71IgKeAzhtBDqnDl-fe_abQT2gWRW-rSG-ep9YwJaz-CE0tsuOxTRDaI9OnueDyn3emULO1T_Eg9Uz-95G9Y0j1WvDfk2q1RymvJaAxcHQz3kwj4ePhKOHW0RfUGQbdaIYy1cC-zPMMUyiK47OMMHar7PyAsgnQ' target='_blank' data-saferedirecturl='https://www.google.com/url?q=http://email.mg.alipata.com/c/eJw1kMGKwyAUAL_GXErCi4lJesghbWhPpYVtL3spRm1rGjVE3cJ-_WrpgshjGGR8vGUEYM0S2WLAAAQwBlLlOMszklcNJrgpi6Lq-36DSlD3bPRK0owZlTxaJggZhoZXxSBEwWu4DbTM180AAHXdNMnUPpybLSo6hHfh0HnOKB-9dfGFAMbKsWdxHT0po7bTZjYzKnq3eIFw5Z26KsGlV4EJReX0gdb4hYm3SLWlzEmj6XSNhg3Kx2JUzVTedfDi71IgKeAzhtBDqnDl-fe_abQT2gWRW-rSG-ep9YwJaz-CE0tsuOxTRDaI9OnueDyn3emULO1T_Eg9Uz-95G9Y0j1WvDfk2q1RymvJaAxcHQz3kwj4ePhKOHW0RfUGQbdaIYy1cC-zPMMUyiK47OMMHar7PyAsgnQ&amp;source=gmail&amp;ust=1590576057624000&amp;usg=AFQjCNGwXvxkwXTJFoxSZPJd1s5nNvlzWA'>
                                                            <img src='https://ci4.googleusercontent.com/proxy/kXiqXvHiRVntG4aGa9a_THpiKPX0yXKpRovDx5x98KeLjjpqZKi-oUWOBfpmlZy7t2vPomT6TSM3LMmLxKR-BOqg172HFlsG0yFeVb6Bg_Y=s0-d-e1-ft#http://alipata.co/nl-templates-nigeria/banners/download_app.png' style='width:100%' class='CToWUd'>
                                                        </a>
                                                    </td>
                                                </tr>
                                            </tbody></table>
                                        </td>
                                        <td style='width:25%;text-align:center;padding-left:5px'>
                                            <table style='width:100%'>
                                                <tbody><tr>
                                                    <td colspan='6' style='column-span:6;text-align:center;font-weight:bold;width:100%'>follow us everywhere</td>
                                                </tr>
                                                <tr>
                                                    <td align='center' width='10%'>
                                                        <a href='' target='_blank' data-saferedirecturl=''>
                                                            <img src='http://alipata.com/images/media/ist.png alt='Instagram' class='CToWUd'>
                                                        </a>
                                                    </td>
                                                    <td align='center' width='10%'>
                                                        <a href='' target='_blank' data-saferedirecturl=''>
                                                            <img src='http://alipata.com/images/media/fb.png' style='width:100%' alt='facebook' class='CToWUd'>
                                                        </a>
                                                    </td>
                                                    <td align='center' width='10%'>
                                                        <a href='' target='_blank' data-saferedirecturl=''>
                                                            <img src='http://alipata.com/images/media/tw.png' style='width:100%' alt='twitter' class='CToWUd'>
                                                        </a>
                                                    </td>
                                                    
                                                </tr>

                                            </tbody></table>
                                        </td>
                                    </tr>
                                </tbody></table>
                            </td>
                        </tr>
                    </tbody></table>
                </td>
            </tr>
        </tbody></table><div class='yj6qo'></div><div class='adL'>

    </div></div><div class='adL'>


</div></div></div><div id=':1q6' class='ii gt' style='display:none'><div id=':1q7' class='a3s aXjCH undefined'></div></div><div class='hi'></div></div>
</body>

</html>";
$htmlContent_All=$htmlContent.$Products.$htmlContent_end;


// Set content-type header for sending HTML email

$headers = "MIME-Version: 1.0" . "\r\n";

$headers .= "Content-type:text/html;charset=UTF-8" . "\r\n";



// Additional headers

$headers .= 'From: Your Alipata Order $orderNo has been confirmed.<info@alipata.com>' . "\r\n";

$headers .= 'Cc: info@alipata.com' . "\r\n";

$headers .= 'Bcc: info@alipata.com' . "\r\n";



// Send email

if(mail($to,$subject,$htmlContent_All,$headers)):

    $successMsg = 'Email has been sent successfully.';

else:

    $errorMsg = 'Email sending failed.';

endif;
    /**************************products******************************/
    unset($_SESSION["products"]);
    echo "<script type=\"text/javascript\">
    alert(\"Your order has successfully.\");
    window.location = \"index\"
    </script>";
    }
catch(PDOException $e)
    {
    $Error= $sql . "<br>" . $e->getMessage();
    }
}
}
 ?>
 <?php echo $Error; ?>
  <form method="post" class=" box-border rounded shadow-sm bg-light p-0" action="<?php echo htmlspecialchars($_SERVER[""]);?>" >
<div class="row p-0 m-0 pt-4 img-rounded shadow-sm p-5">
 <div class="nav-tabs-custom">
            <ul class="nav nav-tabs">
              <li class="active"><a class="box-border p-5 img-rounded border img-rounded btn btn-default active" href="#tab_1" data-toggle="tab" aria-expanded="true">Credit Card</a></li>
              <li class=""><a class="box-border p-5 img-rounded border img-rounded btn btn-default active" href="#tab_2" data-toggle="tab" aria-expanded="false">PayPal</a></li>
              <li><a class="box-border p-5 img-rounded border img-rounded btn btn-default active" href="#tab_3" data-toggle="tab">Manual Transfer</a></li>
            </ul>
            <div class="tab-content">

              <div class="tab-pane box-border img-rounded shadow-sm active" id="tab_1">

                <div class="form-row">
           <!--  <h4 class="">
            <div class=" mb-5  font-weight-bold h4 float-left">
            <div style="border-top: 3px solid #ff3300; max-width: 47px;" >&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</div>
            </div>
            <span class="text-uppercase"> Estimation <br></span>
            </h4> -->
                  <div class="form-group col-md-8">
                    <label for="inputEmail4">Credit Card</label>
                    <input type="text" class="form-control" id="inputEmail4" placeholder="Credit Card" autocomplete="off">
                  </div>
                  <div class="form-group col-md-4">
                    <label for="inputPassword4">Expiry Date</label>
                    <input type="password" class="form-control" value="" id="inputPassword4" placeholder="Expiry Date" autocomplete="off">
                  </div>
                  <div class="form-group col-md-8">
                    <label for="inputEmail4">Name on Card</label>
                    <input type="email" class="form-control" id="inputEmail4" placeholder="Name on Card" autocomplete="off">
                  </div>
                  <div class="form-group col-md-4">
                    <label for="inputPassword4">Code</label>
                    <input type="password" class="form-control" id="inputPassword4" placeholder="Code" autocomplete="off">
                  </div>
                  </div>
              </div>
              <!-- /.tab-pane -->
              <div class="tab-pane" id="tab_2">
                The European languages are members of the same family. Their separate existence is a myth.
                For science, music, sport, etc, Europe uses the same vocabulary. The languages only differ
                in their grammar, their pronunciation and their most common words. Everyone realizes why a
                new common language would be desirable: one could refuse to pay expensive translators. To
                achieve this, it would be necessary to have uniform grammar, pronunciation and more common
                words. If several languages coalesce, the grammar of the resulting language is more simple
                and regular than that of the individual languages.
              </div>
              <!-- /.tab-pane -->
              <div class="tab-pane" id="tab_3">
                Lorem Ipsum is simply dummy text of the printing and typesetting industry.
                Lorem Ipsum has been the industry's standard dummy text ever since the 1500s,
                when an unknown printer took a galley of type and scrambled it to make a type specimen book.
                It has survived not only five centuries, but also the leap into electronic typesetting,
                remaining essentially unchanged. It was popularised in the 1960s with the release of Letraset
                sheets containing Lorem Ipsum passages, and more recently with desktop publishing software
                like Aldus PageMaker including versions of Lorem Ipsum.
              </div>
              <div class="p-1 pt-4">
                <button id="post" type="submit"  name="placeorder" class="btn btn-default active col-sm-12 mb-3"> <span>Place Order   <i class="fa fa-long-arrow-right "></i></span>   </button>
              </div>
              <!-- /.tab-pane -->
            </div>
            <!-- /.tab-content -->
          </div>
  </div>
</form>
</div>
</div>

</div>
 

           
        </div>
    </div>
</div>

</div>


</main>
<!-- end MAIN -->

<?php include 'assets/footer.php'; ?>   
<!-- Insertion Ajax configuration for deposit -->
<script type="text/javascript">
  $(document).ready(function(){
   $(document).on('click','a[data-role=checkout]',function(e){

  event.preventDefault();
  // if( $('#product_id').val() != '')
  // {
    var button_content = $(this).find('a[href=submit]');
    button_content.html('checking out...');
    // button_content.html('Submitted');

   var form_data = $(this).serialize();
   $.ajax({
    url:"manage-check-out.php",
    method:"POST",
    data:form_data,
    success:function(data)
    {
     // alert('True'); 
      // $("#cart-container").html(data.products);
      // data 
      // button_content.html('Deposited <i class="fa fa-check"><i>'); 
      button_content.html('checkout'); 
      // alert(data);
        location.href='checkout'; 
     // $('#comment_form')[0].reset();
     // load_unseen_notification(); 
     // $('#deposit_reciept').modal('show'); 
    }

   });
  // }
  // else
  // {
  //  alert("All Fields are Required");
  // }
 });
 });
</script>
<!-- Insertion Ajax configuration -->
