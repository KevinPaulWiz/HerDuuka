<?php 

session_start();

  // remove all session variables
                unset($_SESSION['customerid']);
// // destroy the session
// session_destroy();
?>
