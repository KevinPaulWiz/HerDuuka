<!DOCTYPE html>
<html>
<head>
	<title>No</title>
</head>
<body>
	<?php 

$html="This is me";

$x = 1;
while($x <= 5) {
    $me= "The number is: $x <br>";
    $x++;
};
echo $html.$me;
	 ?>
</body>
</html>