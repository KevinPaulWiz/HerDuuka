<?php
$currency = 'UGX ';
$shipping_cost =5000.0;
$taxes	= array(
	'VAT' => 0, 
	'Service Tax' => 0,
	'Other Tax' => 0
);
