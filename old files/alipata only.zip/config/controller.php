       <?php
 if ($_SERVER["REQUEST_METHOD"] == "POST") {      
  if (isset($_POST['add_manafacturer'])) {
    $year=date("Y");
    $month=date("M");
    $submitteddate=date("D dS M,Y h:i a");
    $fullnames=$_POST['fullnames'];
    
  try {
    $conn = new PDO("mysql:host=$servername;dbname=$dbname", $username, $password);
    // set the PDO error mode to exception
    $conn->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
    $sql = "INSERT INTO `acount_bal`(`Ac_No`, `actual_bal`, `total_bal`) VALUES ('$Ac_No','$actual_Bal','$Total_Bal')";
    // use exec() because no results are returned
    $conn->exec($sql);
    $Error= "New record created successfully";
    }
catch(PDOException $e)
    {
    $Error= $sql . "<br>" . $e->getMessage();
    }
}
}
?>

<!-- Manufacturers -->
 <?php
 // if ($_SERVER["REQUEST_METHOD"] == "POST") {      
  if (isset($_POST['add_manafacturer'])) {
    $name=$_POST['name'];
    $sort_order=$_POST['sort_order'];
    $filetmp = $_FILES["file_img"]["tmp_name"];
    $filename =  time() . "_" .$_FILES["file_img"]["name"];
    $filetype = $_FILES["file_img"]["type"];
    $filepath = "assets/media/image/manufactures/".$filename;
    $target_file = $filepath . basename($_FILES["file_img"]["name"]);
    $imageFileType = pathinfo($target_file,PATHINFO_EXTENSION);
    $year=date("Y");
    $month=date("M");
    $submitteddate=date("D dS M,Y h:i a");
    $submittedby=$db_username;
    $stat_date=date('Y-m-d');
    
  try {
    $conn = new PDO("mysql:host=$servername;dbname=$dbname", $username, $password);
    // set the PDO error mode to exception
    $conn->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
    $sql = "INSERT INTO `manufacturer`( `name`, `image`, `sort_order`, `stat_date`, `month`, `year`, `submittedby`, `submitteddate`) VALUES ('$name','$filepath','$sort_order','$stat_date','$month','$year','$submittedby','$submitteddate')";
    // use exec() because no results are returned
    $conn->exec($sql);
    move_uploaded_file($filetmp, $filepath);
    // $Error= "New record created successfully";
       echo "<script type=\"text/javascript\">
              alert(\"Record has been added successfully.\");
              window.location = \"\"
            </script>";
    }
catch(PDOException $e)
    {
        // $sql . "<br>" . $e->getMessage();
    $Error= "<div class='alert alert-danger alert-dismissible' role='alert'>
                        <b>Error:</b> '".$e->getMessage()."'
                        <button type='button' class='close' data-dismiss='alert' aria-label='Close'>
                            <i class='ti-close'></i>
                        </button>
                    </div>";
    }
}
// }
?>
<!-- //Manufacturers -->